jQuery.noConflict();
(function ($){
	$(function(){
		$(document).on('click', '.slide-secondary-nav', function(e) {
			e.preventDefault();
			$(this).closest('.nav__wrapper').toggleClass('nav__secondary-active');
		});
		$(document).on('click', '.header__mobile--action-btn', function(e) {
			e.preventDefault();
			$(this).closest('.header__body').toggleClass('mobile-nav-active');
		});

		function close_accordion_section(currentParent) {
			$('#'+ currentParent + ' .accordion-section-title').removeClass('active');
			$('#'+ currentParent + ' .accordion-section-content').slideUp(300).removeClass('open');
		}

		$('.accordion-section-title').click(function(e) {
				// Grab current anchor value
				var currentAttrValue = $(this).attr('href');
				var currentParent = $(this).attr('data-group');

				if($(e.target).is('.active')) {
						close_accordion_section(currentParent);
				}else {
						close_accordion_section(currentParent);

						// Add active class to section title
						$(this).addClass('active');
						// Open up the hidden content panel
						$('#'+ currentParent + ' ' + currentAttrValue).slideDown(300).addClass('open'); 
				}

				e.preventDefault();
		});
		
	});
})(jQuery);