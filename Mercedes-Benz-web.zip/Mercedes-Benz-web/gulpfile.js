'use strict';

var gulp = require('gulp'),
  concat = require('gulp-concat'),
  csso = require('gulp-csso'),
  debug = require('gulp-debug'),
  del = require('del'),
  inject = require('gulp-inject'),
  path = require('path'),
  rename = require('gulp-rename'),
  runSequence = require('run-sequence'),
  sass = require('gulp-sass'),
  series = require('stream-series'),
  size = require('gulp-size'),
  sourcemaps = require('gulp-sourcemaps'),
  uglify = require('gulp-uglify'),
  gutil = require('gulp-util'),
  watch = require('gulp-watch'),
  livereload = require('gulp-livereload'),
  neat = require('node-neat').includePaths,
  bourbon = require('node-bourbon').includePaths,
  normalize = require('node-normalize-scss').includePaths;

var paths = {
  js: ['./src/js/**/*.js'],
  img: ['./src/images/**/*.png', './src/images/**/*.jpg', './src/images/**/*.gif', './src/images/**/*.svg'],
  html: './src/**/*.html',
  scss: [
    'src/styles/main.scss'
  ],
  js_vendor: [
    './bower_components/jquery/dist/jquery.min.js'
  ]
};

/* Run "gulp build" to bulid the source to /dist */
gulp.task('build', function (cb) {
  runSequence(
    'clean', ['styles', 'images', 'scripts', 'copy_libs', 'copy_html'],
    'add_js_to_index',
    cb);
});

gulp.task('clean', function () {
  return del(['dist/**/*']);
});

// Copy images
gulp.task('images', function () {
  return gulp.src(paths.img)
    .pipe(debug())
    .pipe(gulp.dest('./dist/images/'))
    .pipe(size({
      title: 'images'
    }));
});


gulp.task('styles', function () {
  return gulp.src(paths.scss)
    .pipe(sourcemaps.init())
    .pipe(sass({
      includePaths: ['styles'].concat(bourbon, neat, normalize)
    }).on('error', sass.logError))
    .pipe(concat('main.css'))
    .pipe(csso())
    .pipe(sourcemaps.write('./'))
    .pipe(gulp.dest('./dist/styles/'))
    .pipe(size({
      title: 'styles'
    }))
    .pipe(livereload());
});

// Copy all files at the root level (src)
gulp.task('copy_html', function () {
  return gulp.src(paths.html)
    .pipe(gulp.dest('./dist/'));
});

gulp.task('html', function () {
  return gulp.src(paths.html)
    .pipe(livereload());
});

gulp.task('copy_libs', function () {
  return gulp.src(paths.js_vendor)
    .pipe(debug())
    .pipe(gulp.dest(function (file) {
      return './dist/js/' + file.base.replace(file.cwd, '').replace('bower_components', 'vendor').replace('\\', '/');
    }));
});

// Concatenate and minify JavaScript
gulp.task('scripts', function () {
  return gulp.src(paths.js)
    .pipe(concat('main.min.js'))
    .pipe(uglify())
    .on('error', function (err) {
      gutil.log(gutil.colors.red('[Error]'), err.toString());
    })
    .pipe(sourcemaps.init())
    .pipe(sourcemaps.write('./'))
    .pipe(gulp.dest('./dist/js'))
    .pipe(size({
      title: 'scripts'
    }))
    .pipe(livereload());
});

gulp.task('add_js_to_index', function () {
  var super_vendors = gulp.src(['./js/vendor/jquery/dist/*.js'], {
      read: false,
      cwd: 'dist/'
    }),
    vendors = gulp.src(['./js/vendor/**/*.js', '!./js/vendor/jquery/dist/*.js'], {
      read: false,
      cwd: 'dist/'
    }),
    vendorsorder = gulp.src(['./js/vendor/**/*.js', '!./js/vendor/jquery/dist/*.js', '!./js/vendor/jquery-validation/dist/*.js'], {
      read: false,
      cwd: 'dist/'
    }),
    ours = gulp.src(['./js/**/*.js', './js/*.js', '!./js/vendor/**/*.js'], {
      read: false,
      cwd: 'dist/'
    });
  return gulp.src('./src/*.html')
    .pipe(debug())
    .pipe(inject(series(super_vendors, vendors, vendorsorder, ours), {
      starttag: '<!-- inject:js -->',
      endtag: '<!-- endinject -->',
      addRootSlash: false,
      ignorePath: '../dist',
      relative: true,
      removeTags: true
    }))
    .pipe(gulp.dest('./dist/'));
});

/* Run "gulp watch" to watch the css change on save  */

gulp.task('watch', function () {
	livereload.listen();
	gulp.watch("src/styles/**/*.scss", ['styles']);
  gulp.watch(paths.html, ['copy_html']);
  gulp.watch(paths.js, ['scripts']);
});
